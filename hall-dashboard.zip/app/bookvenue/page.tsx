

"use client";
import { useState, useEffect } from 'react';
import {
  TextInput,
  Select,
  Button,
  Group,
  Container,
  Title,
  Notification,
  Grid,
  Text,
  Loader,
  Modal,
  Checkbox,
} from '@mantine/core';
import { DateTimePicker } from '@mantine/dates';
import '@mantine/dates/styles.css';
import 'dayjs/locale/am';
import Cookies from 'js-cookie';
import dayjs from 'dayjs';
import { removeAuthData } from '../utils/auth';

const userDataString = Cookies.get('userData');
const userDataA = userDataString ? JSON.parse(userDataString) : null;

// Validation regex patterns
const phoneNumberRegex = /^(?:\+251|\b251)\d{9}|\b(?:09|07)\d{8}\b(?![-.,])[^-.,]*$/;
const nameRegex = /^[A-Za-z\s]+$/; // Only letters and spaces

export default function MyForm() {
  const [fullName, setFullName] = useState('');
  const [fullNameError, setFullNameError] = useState('');
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [alternativePhoneNumber, setAlternativePhoneNumber] = useState('');
  const [altPhoneError, setAltPhoneError] = useState('');
  const [email, setEmail] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [price, setPrice] = useState('');
  const [isMember, setIsMember] = useState(false);
  const [hallId, setHallId] = useState('');
  const [halls, setHalls] = useState([]);
  const [daysOfWeek, setDaysOfWeek] = useState([]);
  const [promoCodes, setPromoCodes] = useState([]);
  const [selectedPromoCode, setSelectedPromoCode] = useState('');
  const [notification, setNotification] = useState({ visible: false, message: '', color: '' });
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [selectedTerms, setSelectedTerms] = useState([]);
  const [purpose, setPurpose] = useState('');
  const [eventName, setEventName] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalOpened, setModalOpened] = useState(false);
  const [dateError, setDateError] = useState('');
  const [endDateError, setEndDateError] = useState('');

  // Validate phone number
  const validatePhone = (phone: string): boolean => {
    if (!phone) {
      return true; // Empty is handled by required field
    }
    return phoneNumberRegex.test(phone);
  };

  // Validate full name (no numbers)
  const validateFullName = (name: string): boolean => {
    if (!name) {
      return true;
    }
    return nameRegex.test(name);
  };

  // Check if date is future (including today)
  const isFutureDate = (date: Date | null): boolean => {
    if (!date) {
      return true;
    }
    const today = dayjs().startOf('day');
    const selected = dayjs(date).startOf('day');
    return selected.isSame(today) || selected.isAfter(today);
  };

  // Handle phone number change with validation
  const handlePhoneChange = (value: string) => {
    setPhoneNumber(value);
    if (value && !validatePhone(value)) {
      setPhoneError('Please enter a valid Ethiopian phone number (e.g., 0912345678, +251912345678)');
    } else {
      setPhoneError('');
    }
  };

  // Handle alternative phone number change with validation
  const handleAltPhoneChange = (value: string) => {
    setAlternativePhoneNumber(value);
    if (value && !validatePhone(value)) {
      setAltPhoneError('Please enter a valid Ethiopian phone number');
    } else {
      setAltPhoneError('');
    }
  };

  // Handle full name change with validation
  const handleFullNameChange = (value: string) => {
    setFullName(value);
    if (value && !validateFullName(value)) {
      setFullNameError('Full name should only contain letters and spaces');
    } else {
      setFullNameError('');
    }
  };

  // Handle start date change with validation
  const handleStartDateChange = (date: Date | null) => {
    setSelectedDate(date);
    if (date && !isFutureDate(date)) {
      setDateError('Start date must be today or a future date');
    } else {
      setDateError('');
    }
    
    // Clear end date if it's before the new start date
    if (endDate && date && dayjs(endDate).isBefore(dayjs(date))) {
      setEndDate(null);
    }
  };

  // Handle end date change with validation
  const handleEndDateChange = (date: Date | null) => {
    setEndDate(date);
    if (date && selectedDate) {
      if (dayjs(date).isSame(dayjs(selectedDate)) || dayjs(date).isAfter(dayjs(selectedDate))) {
        setEndDateError('');
      } else {
        setEndDateError('End date must be on or after start date');
      }
    } else {
      setEndDateError('');
    }
  };

  useEffect(() => {
    const fetchHalls = async () => {
      setLoading(true);
      try {
        const response = await fetch('https://hall-api.hohitebirhan.com/api/v1/hall', {
          headers: {
            Authorization: `Bearer ${userDataA?.access_token}`
          }
        });

            if (response.status === 401 || response.status === 403 ) {
            removeAuthData();
            window.location.href = '/login';
            throw new Error('Session expired');
          }
        const data = await response.json();
        setHalls(data);
      } catch (error) {
        // Error logged for debugging
      } finally {
        setLoading(false);
      }
    };

    const fetchDaysOfWeek = async () => {
      setLoading(true);
      try {
        const response = await fetch('https://hall-api.hohitebirhan.com/api/v1/payment', {
          headers: {
            Authorization: `Bearer ${userDataA?.access_token}`
          }
        });

          if (response.status === 401 || response.status === 403 ) {
    removeAuthData();
    window.location.href = '/login';
    throw new Error('Session expired');
  }
        const result = await response.json();
        if (result.success) {
          const days = result.data.map((item: any) => ({
            value: item.id,
            label: item.dayOfWeek,
            basePrice: item.basePrice,
            memberPrice: item.memberPrice,
          }));
          setDaysOfWeek(days);
        }
      } catch (error) {
        // Error logged for debugging
      } finally {
        setLoading(false);
      }
    };

    const fetchPromoCodes = async () => {
      setLoading(true);
      try {
        const response = await fetch('https://hall-api.hohitebirhan.com/api/v1/code', {
          headers: {
            Authorization: `Bearer ${userDataA?.access_token}`
          }
        });

            if (response.status === 401 || response.status === 403 ) {
    removeAuthData();
    window.location.href = '/login';
    throw new Error('Session expired');
  }
        const result = await response.json();
        if (result.success) {
          const codes = result.data.map((code: any) => ({
            value: code.code,
            label: code.code,
          }));
          setPromoCodes(codes);
        }
      } catch (error) {
        // Error logged for debugging
      } finally {
        setLoading(false);
      }
    };

    if (userDataA?.access_token) {
      fetchHalls();
      fetchDaysOfWeek();
      fetchPromoCodes();
    }
  }, []);

  const handleHallChange = (value: any) => {
    const selectedHall = halls.find((hall: any) => hall.id === value);
    if (selectedHall) {
      setHallId(value);
      setSelectedTerms(selectedHall.terms);
      setPrice(isMember ? selectedDay?.memberPrice : selectedDay?.basePrice);
    }
  };

  const handleDayChange = (value: any) => {
    const selected = daysOfWeek.find((day: any) => day.value === value);
    if (selected) {
      setSelectedDay(selected);
      setPrice(isMember ? selected.memberPrice : selected.basePrice);
    }
  };

  const userDataString2 = Cookies.get('userData');
  const userData = userDataString2 ? JSON.parse(userDataString2) : null;

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    // Comprehensive validation
    if (!fullName || !selectedDay || !phoneNumber || !email || !hallId || !termsAccepted || !selectedDate || !endDate) {
      setNotification({ visible: true, message: 'Please fill in all required fields and accept the terms.', color: 'red' });
      return;
    }

    // Validate full name format
    if (!validateFullName(fullName)) {
      setNotification({ visible: true, message: 'Full name should only contain letters and spaces', color: 'red' });
      return;
    }

    // Validate phone numbers
    if (!validatePhone(phoneNumber)) {
      setNotification({ visible: true, message: 'Please enter a valid Ethiopian phone number', color: 'red' });
      return;
    }

    if (alternativePhoneNumber && !validatePhone(alternativePhoneNumber)) {
      setNotification({ visible: true, message: 'Please enter a valid alternative phone number', color: 'red' });
      return;
    }

    // Validate dates
    if (!isFutureDate(selectedDate)) {
      setNotification({ visible: true, message: 'Start date must be today or a future date', color: 'red' });
      return;
    }

    if (dayjs(endDate).isBefore(dayjs(selectedDate))) {
      setNotification({ visible: true, message: 'End date must be on or after start date', color: 'red' });
      return;
    }

    setLoading(true);
    const body = {
      hallId,
      startDateTime: selectedDate.toISOString(),
      endDateTime: endDate.toISOString(),
      customerName: fullName,
      email,
      phone: phoneNumber,
      alternativePhoneNumber,
      specialRequests,
      termsAccepted,
      member: isMember,
      promoCode: isMember ? selectedPromoCode : '',
      userId: userData?.userId,
      purpose,
      eventName,
    };

    try {
      const response = await fetch('https://hall-api.hohitebirhan.com/api/v1/book/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${userDataA?.access_token}`
        },
        body: JSON.stringify(body),
      });

          if (response.status === 401 || response.status === 403 ) {
    removeAuthData();
    window.location.href = '/login';
    throw new Error('Session expired');
  }
      if (response.ok) {
        const data = await response.json();
        setNotification({ visible: true, message: data.message, color: 'green' });
        // Reset form on success
        setFullName('');
        setSelectedDay(null);
        setSelectedDate(null);
        setEndDate(null);
        setPhoneNumber('');
        setAlternativePhoneNumber('');
        setEmail('');
        setSpecialRequests('');
        setIsMember(false);
        setHallId('');
        setSelectedPromoCode('');
        setTermsAccepted(false);
        setPurpose('');
        setEventName('');
      } else {
        const errorData = await response.json();
        setNotification({ visible: true, message: `Error: ${errorData.message}`, color: 'red' });
      }
    } catch (error) {
      setNotification({ visible: true, message: 'Network error. Please try again.', color: 'red' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container style={{ marginTop: 40, alignSelf: 'center' }}>
      <Title order={2}>BOOK VENUE</Title>
      {notification.visible && (
        <Notification color={notification.color} onClose={() => setNotification({ ...notification, visible: false })}>
          {notification.message}
        </Notification>
      )}
      {loading && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000,
        }}>
          <Loader size="xl" />
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <Grid>
          <Grid.Col span={6}>
            <TextInput
              label="Full Name"
              placeholder="Enter your full name"
              value={fullName}
              onChange={(event) => handleFullNameChange(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
              error={fullNameError}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <Select
              label="Select Hall"
              placeholder="Choose a hall"
              data={halls.map((hall: any) => ({ value: hall.id, label: hall.name }))}
              value={hallId}
              onChange={handleHallChange}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <Select
              label="Select Day of the Week"
              placeholder="Select a day"
              data={daysOfWeek}
              value={selectedDay?.value}
              onChange={handleDayChange}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Phone Number"
              placeholder="Enter your phone number"
              value={phoneNumber}
              onChange={(event) => handlePhoneChange(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
              error={phoneError}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Alternative Phone Number"
              placeholder="Enter alternative phone number"
              value={alternativePhoneNumber}
              onChange={(event) => handleAltPhoneChange(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
              error={altPhoneError}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Email"
              placeholder="Enter your email"
              value={email}
              onChange={(event) => setEmail(event.currentTarget.value)}
              required
              type="email"
              style={{ marginTop: 10, maxWidth: 300 }}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Special Requests"
              placeholder="Any special requests?"
              value={specialRequests}
              onChange={(event) => setSpecialRequests(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Price for the selected day"
              placeholder="Price"
              disabled
              value={price}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Purpose of Booking"
              placeholder="e.g., Wedding, Conference"
              value={purpose}
              onChange={(event) => setPurpose(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              label="Event Name"
              placeholder="e.g., Ato Abel and Wro Chini Wedding"
              value={eventName}
              onChange={(event) => setEventName(event.currentTarget.value)}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <DateTimePicker
              locale="am"
              label="Start Date"
              placeholder="Select start date"
              value={selectedDate}
              onChange={handleStartDateChange}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
              error={dateError}
              minDate={new Date()} // Prevents selecting past dates in the picker
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <DateTimePicker
              locale="am"
              label="End Date"
              placeholder="Select end date"
              value={endDate}
              onChange={handleEndDateChange}
              style={{ marginTop: 10, maxWidth: 300 }}
              required
              minDate={selectedDate || new Date()} // Ensures end date can't be before start date
              error={endDateError}
            />
          </Grid.Col>
        </Grid>

        <div style={{ marginTop: 20 }}>
          <Button onClick={() => setModalOpened(true)}>View Terms</Button>
        </div>

        <Checkbox
          label="I'm a member"
          checked={isMember}
          onChange={(event) => {
            const isChecked = event.currentTarget.checked;
            setIsMember(isChecked);
            setPrice(isChecked && selectedDay ? selectedDay.memberPrice : selectedDay ? selectedDay.basePrice : '');
          }}
          style={{ marginTop: 20 }}
        />

        {isMember && (
          <Select
            label="Select Promo Code"
            placeholder="Choose a promo code"
            data={promoCodes}
            value={selectedPromoCode}
            onChange={setSelectedPromoCode}
            style={{ marginTop: 10, maxWidth: 300 }}
          />
        )}

        <Group justify="right" mt="md">
          <Button type="submit">BOOK</Button>
        </Group>
      </form>

      {/* Modal for Terms and Conditions */}
      <Modal
        opened={modalOpened}
        onClose={() => setModalOpened(false)}
        title="Terms and Conditions"
        size="lg"
      >
        {selectedTerms.length > 0 ? (
          selectedTerms.map((term: any) => (
            <Text key={term.id}>{term.termsText}</Text>
          ))
        ) : (
          <Text>No terms available for the selected hall.</Text>
        )}
        <Group justify="right" mt="md">
          <Button onClick={() => {
            setTermsAccepted(true);
            setModalOpened(false);
          }}>Accept</Button>
          <Button onClick={() => setModalOpened(false)}>Decline</Button>
        </Group>
      </Modal>
    </Container>
  );
}